package Biblioteca;

public class GestoraMenus {
    public static void mostrarMenu() {
        System.out.println("\n1. Alquilar libro");
        System.out.println("2. Devolver libro");
        System.out.println("3. Dar de alta un usuario");
        System.out.println("4. Dar de baja un usuario");
        System.out.println("5. Registrar un nuevo libro");
        System.out.println("6. Dar de baja un libro");
        System.out.println("7. Listado de usuarios y sus libros alquilados");
        System.out.println("0. Salir");
    }
}
