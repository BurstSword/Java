package Ejercicio3;

public class GestoraMenus {
    public static void mostrarMenu() {
        System.out.println("\n1. Alquilar publicaci�n");
        System.out.println("2. Devolver publicaci�n");
        System.out.println("3. Dar de alta un usuario");
        System.out.println("4. Dar de baja un usuario");
        System.out.println("5. Registrar una nueva publicaci�n");
        System.out.println("6. Dar de baja una publicaci�n");
        System.out.println("7. Listado de usuarios y sus publicaciones alquiladas");
        System.out.println("0. Salir");
    }
}
