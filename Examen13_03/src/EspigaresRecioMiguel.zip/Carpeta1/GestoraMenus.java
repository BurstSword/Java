package Carpeta1;

public class GestoraMenus {
    //Clase encargada de los menus del programa
    public static void menuPrincipal() {
        System.out.println("\nBienvenido a la escuela, elija la opción correspodiente a la acción que quiera realizar");
        System.out.println("1. Ver listado de los alumnos");
        System.out.println("2. Calificar alumno de primero");
        System.out.println("3. Calificar alumno de segundo");
        System.out.println("4. Mostrar nota media de ambos cursos");
        System.out.println("5. Salir");
    }
}
