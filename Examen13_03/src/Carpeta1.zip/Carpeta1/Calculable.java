package Carpeta1;

import java.util.ArrayList;

public interface Calculable {

    float calcularMedia(ArrayList<Float> notas);
}
