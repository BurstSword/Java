package Carpeta1;



public interface Imprimible {
    void imprimirString();

    void imprimirArrayList();

}
