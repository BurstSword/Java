package Ejercicio1.Gestoras;

public class GestoraMenus {

    public static void menu (){
        System.out.println("\n Bienvenido a la biblioteca");
        System.out.println("1. Mostrar listado de publicaciones");
        System.out.println("2. Prestar libro");
        System.out.println("3. Devolver libro");
        System.out.println("4. Leer revista");
        System.out.println("5. Dejar de leer revista");
        System.out.println("6. Salir");
    }
}
