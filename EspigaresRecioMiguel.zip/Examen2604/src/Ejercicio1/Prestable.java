package Ejercicio1;

public interface Prestable {
    void prestarLibro();


    void recibirLibroDeVuelta();
}
