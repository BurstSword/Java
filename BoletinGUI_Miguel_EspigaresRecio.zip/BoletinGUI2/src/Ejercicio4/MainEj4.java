package Ejercicio4;

public class MainEj4 {
    public static void main(String[] args) {
        Ejercicio4GUI ejercicio4GUI = new Ejercicio4GUI();
        ejercicio4GUI.setVisible(true);
        ejercicio4GUI.setSize(500,300);
    }
}
