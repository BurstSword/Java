package Ejercicio3;

public class MainEj3 {
    public static void main(String[] args) {
        Ejercicio3GUI ejercicio3GUI = new Ejercicio3GUI();
        ejercicio3GUI.setVisible(true);
        ejercicio3GUI.setSize(300,200);
    }
}
