package Ejercicio10;

public class MainEj10 {
    public static void main(String[] args) {
        Ejercicio10GUI ejercicio10GUI = new Ejercicio10GUI();
        ejercicio10GUI.setVisible(true);
    }
}
