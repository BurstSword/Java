package Gestoras;


public class GestoraMenu {
    public static void menuPrincipal(){
        System.out.println("Bienvenido");
        System.out.println("1. Crear personajes");
        System.out.println("2. Gestoras.GestoraDado");
        System.out.println("Bienvenido");
    }
}
