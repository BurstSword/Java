

import java.util.Scanner;

public class Menu {
	static Scanner sc = new Scanner(System.in);

	public static void menu() {

		System.out.println("Elige una de las siguientes opciones"
				+ "\n1: Lanzar Dado"
				+ "\n2: Crear personajes"
				+ "\n3: Luchar"
				+ "\n4: Salir");
	}

}
