package comandas.MiguelEspigaresRecio;

import java.util.ArrayList;
import java.util.Arrays;

public class Datos {

    private static Camarero[] arrayC = new Camarero[] {};
    public static ArrayList<Camarero> listaComandas = new ArrayList<>(Arrays.asList(arrayC));

}
