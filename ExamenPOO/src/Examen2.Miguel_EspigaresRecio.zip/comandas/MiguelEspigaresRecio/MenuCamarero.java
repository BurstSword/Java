package comandas.MiguelEspigaresRecio;

public class MenuCamarero {
    int boton;


}
