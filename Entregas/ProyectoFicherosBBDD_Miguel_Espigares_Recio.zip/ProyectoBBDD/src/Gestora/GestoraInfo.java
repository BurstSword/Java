package Gestora;
/*
Clase encargada de almacenar los datos del usuario que est� utilizando la aplicaci�n
 */
import Entidades.Usuario;

public class GestoraInfo {

public static Usuario usuario;
}
