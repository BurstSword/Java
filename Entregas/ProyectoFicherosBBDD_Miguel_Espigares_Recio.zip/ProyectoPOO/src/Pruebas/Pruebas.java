package Pruebas;

import Entidades.Guerrero;
import Entidades.Monstruo;
import Gestoras.GestoraGuerrero;
import Gestoras.GestoraMonstruo;
import Gestoras.GestoraPeleas;
import Utilidades.Utilidades;

public class Pruebas {
    public static void main(String[] args) {
     /*   Guerrero guerrero = GestoraGuerrero.generarGuerrero("Óscar");
        Monstruo monstruo = GestoraMonstruo.generarMonstruo(guerrero.getVidaMax(),guerrero.getAtaque());
        char[] arrayFinPartida = {'F', 'i', 'n', ' ', 'd', 'e', ' ', 'p', 'a', 'r', 't', 'i', 'd', 'a'};
        String mensajeCompleto = "";


        for (int i = 0; i < arrayFinPartida.length; i++) {
            mensajeCompleto += arrayFinPartida[i];
            if(i != 0)
                System.out.print("\r"+mensajeCompleto);
            else
                System.out.print(mensajeCompleto);
            Utilidades.esperarFin();
       }

        //GestoraPeleas.pelear(monstruo,guerrero);

       /* System.out.println("   |\\                     /)\n" +
                " /\\_\\\\__               (_//\n" +
                "|   `>\\-`     _._       //`)\n" +
                " \\ /` \\\\  _.-`:::`-._  //\n" +
                "  `    \\|`    :::    `|/\n" +
                "        |     :::     |\n" +
                "        |.....:::.....|\n" +
                "        |:::::::::::::|\n" +
                "        |     :::     |\n" +
                "        \\     :::     /\n" +
                "         \\    :::    /\n" +
                "          `-. ::: .-'\n" +
                "           //`:::`\\\\\n" +
                "          //   '   \\\\\n" +
                "         |/         \\\\");

        //Utilidades.mejorarEquipamiento();
        Utilidades.subirDinero(300, 50);
        */
    }


}
