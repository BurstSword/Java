package Ejercicio5;

public class MainEj5 {
    public static void main(String[] args) {
        Ejercicio5GUI ejercicio5GUI = new Ejercicio5GUI();
        ejercicio5GUI.setVisible(true);
        ejercicio5GUI.setSize(400,100);
    }
}
