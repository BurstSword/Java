package Ejercicio6;

public class MainEj6 {
    public static void main(String[] args) {
        Ejercicio6GUI ejercicio6GUI = new Ejercicio6GUI();
        ejercicio6GUI.setVisible(true);
        ejercicio6GUI.setSize(500,170);
    }
}
