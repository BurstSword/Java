package Ejercicio7;

public class MainEj7 {
    public static void main(String[] args) {
        Ejercicio7GUI ejercicio7GUI = new Ejercicio7GUI();
        ejercicio7GUI.setVisible(true);
        ejercicio7GUI.setSize(150,100);

    }
}
