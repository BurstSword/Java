package Ejercicio9;

public class MainEj9 {
    public static void main(String[] args) {
        Ejercicio9GUI ejercicio9GUI = new Ejercicio9GUI();
        ejercicio9GUI.setVisible(true);
        ejercicio9GUI.setSize(300,200);
    }
}
