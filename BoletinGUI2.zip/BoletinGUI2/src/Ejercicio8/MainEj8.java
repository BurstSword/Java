package Ejercicio8;

public class MainEj8 {
    public static void main(String[] args) {
        Ejercicio8GUI ejercicio8GUI = new Ejercicio8GUI();
        ejercicio8GUI.setVisible(true);
        ejercicio8GUI.setSize(350,250);
    }
}
