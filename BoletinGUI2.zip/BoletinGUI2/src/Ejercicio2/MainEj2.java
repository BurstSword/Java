package Ejercicio2;

public class MainEj2 {
    public static void main(String[] args) {
        Ejercicio2GUI ejercicio2GUI = new Ejercicio2GUI();
        ejercicio2GUI.setVisible(true);
        ejercicio2GUI.setSize(300,100);
    }
}
