package Ejercicio1;

public class MainEj1 {
    public static void main(String[] args) {
        Ejercicio1GUI ejercicio1GUI = new Ejercicio1GUI();
        ejercicio1GUI.setVisible(true);
        ejercicio1GUI.setSize(500,300);
    }

}
